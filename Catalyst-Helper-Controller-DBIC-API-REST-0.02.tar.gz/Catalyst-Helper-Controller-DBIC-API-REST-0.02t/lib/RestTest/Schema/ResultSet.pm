package # hide from PAUSE 
    RestTest::Schema::ResultSet;

use base 'DBIx::Class::ResultSet';

1;
